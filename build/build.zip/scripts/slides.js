$(function() {
          $(".rslides").responsiveSlides({
              auto: false,
              pager: false,
              nav: true,
              speed: 500,
              namespace: "centered-btns"
          });
      });