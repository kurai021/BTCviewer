String.toLocaleString({
    "es":{
        "%charts": "Gráficos",
        "%input": "Entrada",
        "%amount-input": "Cantidad",
        "%currency-input": "Moneda",
        "%output": "Salida",
        "%amount-output": "Cantidad",
        "%currency-output": "Moneda",
        "%converter": "Convertidor",
        "%paragraph-about": "Convertidor de BTC y otras monedas y visor de grafico de precios (USD, EUR, CNY and GBP)",
        "%span-about": "Si te gustó esta app, podrias donar algunos Bitcoins: ",
        "%em-about": "Este software es licenciado bajo la: ",
        "news": "Noticias (inglés)",
        "news2": "Noticias (inglés)",
        "ok_about": "Aceptar",
        "quit": "Salir"
    }
});